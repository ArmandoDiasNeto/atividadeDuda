<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\TipoDeAnimal;

class TipodeAnimalController extends Controller
{
    public function store(Request $request)
    {
        $tipodeanimal = new TipoDeAnimal();
        $tipodeanimal->descricao = $request->descricao;
        $tipodeanimal->save();
    }

    public function index()
    {
        $tipodeanimal = new TipoDeAnimal();
        return $tipodeanimal->all();
    }
    public function update(Request $request, $id)
    {
        $tipodeanimal = TipoDeAnimal::find($id);
        $tipodeanimal->descricao = $request->descricao;
        return $tipodeanimal->save();
    }
    public function destroy()
    {
        $tipodeanimal = new TipoDeAnimal();
        return $tipodeanimal->all();
    }

    //public function show($id)
    //{
        //$time = new Time();
        //$time = $time->find($id);
        //return $time;
    //}
}
