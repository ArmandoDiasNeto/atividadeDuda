<?php

namespace Database\Seeders;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class AnimalSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('tipodeanimal')->insert([
            'descricao' => 'Cachorro'
        ]);
        DB::table('tipodeanimal')->insert([
            'descricao' => 'Gato'
        ]);
        DB::table('tipodeanimal')->insert([
            'descricao' => 'Passáro'
        ]);
        DB::table('tipodeanimal')->insert([
            'descricao' => 'Coelho'
        ]);
    }
}
